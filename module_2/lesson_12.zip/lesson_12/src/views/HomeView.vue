<template>
  <div>
    <h1>Home</h1>
    <RouterView></RouterView>
  </div>
</template>
<script>
export default {
 name:"home"
}
</script>
<style>
  
</style>