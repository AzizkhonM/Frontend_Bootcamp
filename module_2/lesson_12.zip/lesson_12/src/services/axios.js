import axios from "axios";

axios.defaults.baseURL="http://83.229.87.144:3000/api";

export default axios;